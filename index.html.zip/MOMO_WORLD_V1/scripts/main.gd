extends Node2D

# MOMO WORLD - Snake Prototype V1
# Godot 4.x | 720x1280 portrait | no external assets required

const CELL := 24
const COLS := 24
const ROWS := 32
const BOARD_W := COLS * CELL
const BOARD_H := ROWS * CELL
const BOARD_X := 72
const BOARD_Y := 300
const STEP_TIME := 0.16

const BG := Color("#F5F7E9")
const BOARD_COLOR := Color("#FFFFFF")
const GRID_COLOR := Color("#EDF1E4")
const GREEN := Color("#58C98A")
const DARK_GREEN := Color("#269B69")
const TEXT_COLOR := Color("#315B4A")
const PINK := Color("#FF8E9E")
const GOLD := Color("#FFD36A")

var rng := RandomNumberGenerator.new()
var snake: Array[Vector2i] = []
var direction := Vector2i.RIGHT
var next_direction := Vector2i.RIGHT
var food := Vector2i(12, 16)
var score := 0
var state := "menu" # menu, playing, paused, gameover
var move_accumulator := 0.0
var touch_start := Vector2.ZERO

func _ready() -> void:
    rng.randomize()
    _reset_game()
    queue_redraw()

func _process(delta: float) -> void:
    if state == "playing":
        move_accumulator += delta
        while move_accumulator >= STEP_TIME:
            move_accumulator -= STEP_TIME
            _step_game()
    queue_redraw()

func _reset_game() -> void:
    snake.clear()
    snake.append(Vector2i(10, 16))
    snake.append(Vector2i(9, 16))
    snake.append(Vector2i(8, 16))
    direction = Vector2i.RIGHT
    next_direction = Vector2i.RIGHT
    score = 0
    move_accumulator = 0.0
    _spawn_food()

func _start_game() -> void:
    _reset_game()
    state = "playing"

func _spawn_food() -> void:
    var candidate := Vector2i.ZERO
    var attempts := 0
    while attempts < 1000:
        candidate = Vector2i(rng.randi_range(0, COLS - 1), rng.randi_range(0, ROWS - 1))
        if not snake.has(candidate):
            food = candidate
            return
        attempts += 1

func _step_game() -> void:
    direction = next_direction
    var new_head: Vector2i = snake[0] + direction

    if new_head.x < 0 or new_head.x >= COLS or new_head.y < 0 or new_head.y >= ROWS:
        state = "gameover"
        return

    var will_eat := new_head == food
    var body_to_check := snake.size() if will_eat else snake.size() - 1
    for i in range(body_to_check):
        if snake[i] == new_head:
            state = "gameover"
            return

    snake.push_front(new_head)
    if will_eat:
        score += 10
        _spawn_food()
    else:
        snake.pop_back()

func _set_direction(new_direction: Vector2i) -> void:
    if new_direction + direction == Vector2i.ZERO:
        return
    next_direction = new_direction

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        match event.keycode:
            KEY_UP, KEY_W:
                _set_direction(Vector2i.UP)
            KEY_DOWN, KEY_S:
                _set_direction(Vector2i.DOWN)
            KEY_LEFT, KEY_A:
                _set_direction(Vector2i.LEFT)
            KEY_RIGHT, KEY_D:
                _set_direction(Vector2i.RIGHT)
            KEY_SPACE:
                if state == "menu" or state == "gameover":
                    _start_game()
                elif state == "playing":
                    state = "paused"
                elif state == "paused":
                    state = "playing"

    if event is InputEventScreenTouch:
        if event.pressed:
            touch_start = event.position
        else:
            _handle_tap_or_swipe(event.position)

    if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed:
            touch_start = event.position
        else:
            _handle_tap_or_swipe(event.position)

func _handle_tap_or_swipe(end_pos: Vector2) -> void:
    var delta := end_pos - touch_start
    if state == "menu":
        if _inside_button(end_pos, Vector2(210, 900), Vector2(510, 100)):
            _start_game()
        return
    if state == "gameover":
        if _inside_button(end_pos, Vector2(210, 900), Vector2(300, 100)):
            _start_game()
        return
    if state == "paused":
        if _inside_button(end_pos, Vector2(210, 900), Vector2(300, 100)):
            state = "playing"
        return
    if state == "playing":
        if _inside_button(end_pos, Vector2(560, 115), Vector2(100, 70)):
            state = "paused"
            return
        if delta.length() > 28:
            if absf(delta.x) > absf(delta.y):
                _set_direction(Vector2i.RIGHT if delta.x > 0 else Vector2i.LEFT)
            else:
                _set_direction(Vector2i.DOWN if delta.y > 0 else Vector2i.UP)
        else:
            # Tap the lower screen quadrants as simple directional controls.
            if end_pos.y > 1080:
                if end_pos.x < 180:
                    _set_direction(Vector2i.LEFT)
                elif end_pos.x > 540:
                    _set_direction(Vector2i.RIGHT)
                elif end_pos.x < 360:
                    _set_direction(Vector2i.DOWN)
                else:
                    _set_direction(Vector2i.UP)

func _inside_button(point: Vector2, top_left: Vector2, size: Vector2) -> bool:
    return Rect2(top_left, size).has_point(point)

func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO, Vector2(720, 1280)), BG)

    _draw_header()
    _draw_board()

    if state == "menu":
        _draw_menu()
    elif state == "paused":
        _draw_overlay("TẠM DỪNG", "Chạm nút bên dưới để chơi tiếp", "CHƠI TIẾP")
    elif state == "gameover":
        _draw_overlay("ÔI! HẾT LƯỢT RỒI", "Điểm của bạn: " + str(score), "CHƠI LẠI")
    else:
        _draw_controls_hint()

func _draw_header() -> void:
    _center_text("MOMO WORLD", 95, 48, TEXT_COLOR)
    _center_text("CUỘC PHIÊU LƯU CỦA MOMO", 140, 20, DARK_GREEN)

    _draw_pill(Rect2(72, 185, 250, 76), Color("#FFFFFF"))
    _text("ĐIỂM", Vector2(100, 216), 17, Color("#7A9B88"))
    _text(str(score), Vector2(100, 247), 29, TEXT_COLOR)

    _draw_pill(Rect2(398, 185, 250, 76), Color("#FFFFFF"))
    _text("CHIỀU DÀI", Vector2(426, 216), 17, Color("#7A9B88"))
    _text(str(snake.size()), Vector2(426, 247), 29, TEXT_COLOR)

    if state == "playing":
        _draw_pill(Rect2(560, 105, 88, 58), Color("#FFFFFF"))
        _center_text_at("Ⅱ", Vector2(604, 145), 32, TEXT_COLOR)

func _draw_board() -> void:
    _draw_pill(Rect2(BOARD_X - 8, BOARD_Y - 8, BOARD_W + 16, BOARD_H + 16), Color("#DDE8D8"))
    draw_rect(Rect2(BOARD_X, BOARD_Y, BOARD_W, BOARD_H), BOARD_COLOR)

    for x in range(COLS + 1):
        var px := BOARD_X + x * CELL
        draw_line(Vector2(px, BOARD_Y), Vector2(px, BOARD_Y + BOARD_H), GRID_COLOR, 1.0)
    for y in range(ROWS + 1):
        var py := BOARD_Y + y * CELL
        draw_line(Vector2(BOARD_X, py), Vector2(BOARD_X + BOARD_W, py), GRID_COLOR, 1.0)

    _draw_food()
    _draw_snake()

func _draw_snake() -> void:
    for i in range(snake.size() - 1, -1, -1):
        var p := _cell_center(snake[i])
        var radius := 10.5
        var body_color := GREEN if i % 2 == 0 else Color("#70D99A")
        if i == 0:
            body_color = DARK_GREEN
            radius = 12.0
        draw_circle(p, radius, body_color)
        if i == 0:
            # Big friendly eyes, placed toward the direction of travel.
            var eye_offset := Vector2(direction) * 4.0
            var side_offset := Vector2(-direction.y, direction.x) * 4.0
            draw_circle(p + eye_offset + side_offset, 3.0, Color.WHITE)
            draw_circle(p + eye_offset - side_offset, 3.0, Color.WHITE)
            draw_circle(p + eye_offset + side_offset + Vector2(0, 1), 1.3, TEXT_COLOR)
            draw_circle(p + eye_offset - side_offset + Vector2(0, 1), 1.3, TEXT_COLOR)

func _draw_food() -> void:
    var p := _cell_center(food)
    draw_circle(p, 10.0, PINK)
    draw_circle(p + Vector2(-3, -3), 2.5, Color("#FFD8DE"))
    draw_line(p + Vector2(1, -9), p + Vector2(4, -14), DARK_GREEN, 2.5)
    draw_colored_polygon(PackedVector2Array([
        p + Vector2(3, -12), p + Vector2(10, -15), p + Vector2(7, -8)
    ]), GREEN)

func _draw_menu() -> void:
    _center_text("Xin chào! Mình là Momo", 1110, 25, TEXT_COLOR)
    _center_text("Vuốt màn hình để điều khiển chú rắn nhé!", 1150, 18, Color("#668575"))
    _draw_button(Rect2(210, 900, 300, 100), "BẮT ĐẦU", GREEN)
    _center_text("Ăn trái cây và lớn lên thật vui!", 1045, 18, DARK_GREEN)

func _draw_controls_hint() -> void:
    _center_text("VUỐT THEO HƯỚNG MUỐN ĐI", 1120, 20, TEXT_COLOR)
    _center_text("Ăn trái cây để nhận thêm điểm!", 1155, 17, Color("#668575"))

func _draw_overlay(title: String, subtitle: String, button_label: String) -> void:
    draw_rect(Rect2(0, 0, 720, 1280), Color(0.12, 0.22, 0.17, 0.48))
    _draw_pill(Rect2(90, 470, 540, 360), Color("#FFFFFF"))
    _center_text_at(title, Vector2(360, 565), 34, TEXT_COLOR)
    _center_text_at(subtitle, Vector2(360, 630), 22, Color("#668575"))
    _draw_button(Rect2(210, 900, 300, 100), button_label, GREEN)

func _draw_button(rect: Rect2, label: String, color: Color) -> void:
    _draw_pill(rect, color)
    _center_text_at(label, rect.position + rect.size / 2.0 + Vector2(0, 10), 27, Color.WHITE)

func _draw_pill(rect: Rect2, color: Color) -> void:
    var r := rect.size.y / 2.0
    draw_rect(Rect2(rect.position.x + r, rect.position.y, rect.size.x - 2.0 * r, rect.size.y), color)
    draw_circle(Vector2(rect.position.x + r, rect.position.y + r), r, color)
    draw_circle(Vector2(rect.end.x - r, rect.position.y + r), r, color)

func _cell_center(cell: Vector2i) -> Vector2:
    return Vector2(BOARD_X + cell.x * CELL + CELL / 2.0, BOARD_Y + cell.y * CELL + CELL / 2.0)

func _text(value: String, pos: Vector2, size: int, color: Color) -> void:
    draw_string(ThemeDB.fallback_font, pos, value, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)

func _center_text(value: String, baseline_y: float, size: int, color: Color) -> void:
    _center_text_at(value, Vector2(360, baseline_y), size, color)

func _center_text_at(value: String, center: Vector2, size: int, color: Color) -> void:
    var font := ThemeDB.fallback_font
    var width := font.get_string_size(value, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
    draw_string(font, Vector2(center.x - width / 2.0, center.y), value, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)
