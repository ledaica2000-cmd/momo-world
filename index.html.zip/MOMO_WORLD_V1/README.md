# MOMO WORLD – Prototype V1

A tiny 2D snake game prototype built with Godot 4.x.

## Included
- Portrait 720x1280 layout
- Cute snake drawn with shapes (no external art needed)
- Fruit spawning and score
- Swipe controls on touch screens
- Arrow keys / WASD for desktop testing
- Pause, game over, and restart

## Run
1. Install Godot 4.x from https://godotengine.org/
2. Extract this ZIP.
3. In Godot, choose **Import** and select `project.godot`.
4. Open the project and press **F6** (or **F5** to run the main scene).

## Controls
- Phone: swipe up/down/left/right.
- Desktop: arrow keys or WASD.
- Space: start / pause / resume.

## Current limitations
- This is a prototype, not a store-ready release.
- Art is drawn with simple shapes and placeholder colors.
- No ads, analytics, accounts, purchases, or online features.
- Before publishing for children, add age-appropriate privacy protections,
  parental information where required, and compliant ad settings.

## Next milestones
1. Playtest speed and controls.
2. Add polished character and fruit sprites.
3. Add sound, settings, and accessibility options.
4. Add more levels and cosmetic unlocks.
5. Review child-safety, privacy, and store requirements before monetization.
